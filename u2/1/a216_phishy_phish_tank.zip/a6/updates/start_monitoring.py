# start_monitoring.py
import tkinter as tk 
import fishtank as tank
my_tank = tank.FishTank() 
my_tank.mainloop()
