# Sources

- [Keras Documentation](https://keras.io/)
- [IBM Machine Learning](https://www.ibm.com/cloud/learn/machine-learning)
- [History of Machine Learning](https://www.dataversity.net/a-brief-history-of-machine-learning/)
- [Machine Learning Visual](https://www.favouriteblog.com/wp-content/uploads/2017/07/Types-of-Learning.png)
- [Neural Network Visual](https://amitranga.files.wordpress.com/2014/02/neural_network_image-e1393189026928.png)
